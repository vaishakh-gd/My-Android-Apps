package com.example.vaishakhgd.mycaller2;

/**
 * Created by vaishakh g d on 25-07-2017.
 */
public class Service {



}
