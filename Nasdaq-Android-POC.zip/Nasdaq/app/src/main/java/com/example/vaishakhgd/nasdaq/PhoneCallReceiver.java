package com.example.vaishakhgd.nasdaq;

import android.telephony.TelephonyManager;

import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.support.annotation.NonNull;

import java.util.*;
/**
 * Created by vaishakh g d on 20-06-2017.
 */
public class PhoneCallReceiver {

    private static int lastState = TelephonyManager.CALL_STATE_IDLE;

    private static Date callStartTime;

    private static boolean isIncoming;

    private static String savedNumber;  //because the passed incoming is only valid in ringing





    @Override

    public void onReceive(Context context, Intent intent) {



        //We listen to two intents.  The new outgoing call only tells us of an outgoing call.  We use it to get the number.

        if (intent.getAction().equals("android.intent.action.NEW_OUTGOING_CALL")) {

            savedNumber = intent.getExtras().getString("android.intent.extra.PHONE_NUMBER");

        }

        else{

            String stateStr = intent.getExtras().getString(TelephonyManager.EXTRA_STATE);

            String number = intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);

            int state = 0;

            if(stateStr.equals(TelephonyManager.EXTRA_STATE_IDLE)){

                state = TelephonyManager.CALL_STATE_IDLE;

            }

            else if(stateStr.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)){

                state = TelephonyManager.CALL_STATE_OFFHOOK;

            }

            else if(stateStr.equals(TelephonyManager.EXTRA_STATE_RINGING)){

                state = TelephonyManager.CALL_STATE_RINGING;

            }





            onCallStateChanged(context, state, number);

        }



    }
