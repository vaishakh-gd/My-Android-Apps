package com.example.vaishakhgd.nasdaq;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by vaishakh g d on 15-06-2017.
 */
public class SmsBroadcastReceiver extends BroadcastReceiver {

    String smsbundle="pdus";

    public void onReceive(Context context, Intent intent)
    {
        Toast.makeText(context,"",Toast.LENGTH_SHORT).show();
        Bundle intentExtras=intent.getExtras();
        if(intentExtras!=null) {
            Object[] sms = (Object[]) intentExtras.get(smsbundle);
            String msgstr = "";

            for (int i = 0; i < sms.length; i++) {
                String format = intentExtras.getString("format");
                SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) sms[i], format);

                String smsbody = smsMessage.getMessageBody().toString();
                String address = smsMessage.getOriginatingAddress();
                msgstr += "from:" + address + "\n" + smsbody + "\n";
                Log.i("msg is:",msgstr);
            }
            if(MainActivity.active) {
                MainActivity obj = new MainActivity();
                MainActivity inst = obj.instance();
                inst.updateInbox(msgstr);
            }

            else
            {

                Intent i=new Intent(context,MainActivity.class);

                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }

        }

    }


}
