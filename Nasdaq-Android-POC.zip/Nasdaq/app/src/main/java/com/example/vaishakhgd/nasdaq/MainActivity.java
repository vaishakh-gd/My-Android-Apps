package com.example.vaishakhgd.nasdaq;

import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.support.annotation.NonNull;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
   static MainActivity inst;
    static boolean active=false;
    public void onStart()
    {
        super.onStart();
        active=true;
        inst=this;
    }

    public void onStop()
    {
        super.onStop();
        active=false;

    }
    public  MainActivity instance(){
        return  inst;
    }


    ArrayList<String> smsMessagesList = new ArrayList<>();
    ListView messages;
    ArrayAdapter arrayAdapter;
    private static final int READ_SMS_PERMISSIONS_REQUEST = 1;
    EditText input;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        messages = (ListView) findViewById(R.id.listView);
        input =  (EditText) findViewById(R.id.editText);
        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, smsMessagesList);
        messages.setAdapter(arrayAdapter);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            getPermissionToReadSMS();
        } else {
            refreshSmsInbox();
        }
    }



    public void getPermissionToReadSMS() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (shouldShowRequestPermissionRationale(
                    Manifest.permission.READ_SMS)) {
                Toast.makeText(this, "Please allow permission!", Toast.LENGTH_SHORT).show();
            }
            requestPermissions(new String[]{Manifest.permission.READ_SMS},
                    READ_SMS_PERMISSIONS_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
        // Make sure it's our original READ_CONTACTS request
        if (requestCode == READ_SMS_PERMISSIONS_REQUEST) {
            if (grantResults.length == 1 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Read SMS permission granted", Toast.LENGTH_SHORT).show();
                refreshSmsInbox();
            } else {
                Toast.makeText(this, "Read SMS permission denied", Toast.LENGTH_SHORT).show();
            }

        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
    public void refreshSmsInbox(){

        ContentResolver contentResolver=getContentResolver();
        Cursor smsInboxCursor=contentResolver.query(Uri.parse("content://sms/inbox"),null,null,null,null);
        int indexBody=smsInboxCursor.getColumnIndex("body");
        int indexAddress=smsInboxCursor.getColumnIndex("address");
        arrayAdapter.clear();

        while(smsInboxCursor.moveToNext())
        {
            //if(smsInboxCursor.getString(indexAddress).contains("DMNOTIFY"))
            {
                String str = "SMS FROM:" + smsInboxCursor.getString(indexAddress) + "\n" + smsInboxCursor.getString(indexBody) + "\n";
                arrayAdapter.add(str);
            }

        }

    }
    String s1="";
    public  void updateInbox(String msgstr)
    {

        TextView tv3= (TextView) findViewById(R.id.textView3);
        String s2=tv3.getText()+msgstr;
        s1+=s2;
        tv3.setText(s1);
        if(s1!="" && s1.contains("DMNOTIFY"))
        {

            Uri not= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r=RingtoneManager.getRingtone(getApplicationContext(),not);
            r.play();
        }
        s1=""; //this works



    }
}
